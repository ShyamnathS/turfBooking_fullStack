package com.example.demo.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.Turf;
import com.example.demo.repository.TurfRepository;

@Service
public class TurfService {

    @Autowired
    private TurfRepository turfRepository;

    public List<Turf> getAllTurfs() {
        return turfRepository.findAll();
    }

    public Turf getTurfById(Long id) {
        return turfRepository.findById(id).orElse(null);
    }

    public Turf addTurf(Turf turf) {
        return turfRepository.save(turf);
    }

    public Turf updateTurf(Long id, Turf updatedTurf) {
        return turfRepository.findById(id)
                .map(turf -> {
                    if (updatedTurf.getTitle() != null) turf.setTitle(updatedTurf.getTitle());
                    if (updatedTurf.getRating() >= 0) turf.setRating(updatedTurf.getRating());
                    if (updatedTurf.getAddress() != null) turf.setAddress(updatedTurf.getAddress());
                    if (updatedTurf.getServices() != null) turf.setServices(updatedTurf.getServices());
                    if (updatedTurf.getPhone() != null) turf.setPhone(updatedTurf.getPhone());
                    if (updatedTurf.getImage() != null) turf.setImage(updatedTurf.getImage());
                    return turfRepository.save(turf);
                }).orElse(null);
    }

    public void deleteTurf(Long id) {
        turfRepository.deleteById(id);
    }
}
