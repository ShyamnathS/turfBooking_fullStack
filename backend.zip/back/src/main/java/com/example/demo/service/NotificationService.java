package com.example.demo.service;

import com.example.demo.model.Notification;
import com.example.demo.model.Turf;
import com.example.demo.repository.NotificationRepository;
import com.example.demo.repository.TurfRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class NotificationService {

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private TurfRepository turfRepository;

    public List<Notification> getAllNotifications() {
        return notificationRepository.findAll();
    }

    public Notification addNotification(Notification notification) {
        return notificationRepository.save(notification);
    }

    public void acceptNotification(Long id) {
        notificationRepository.findById(id).ifPresent(notification -> {
            Turf turf = new Turf();
            turf.setTitle(notification.getTitle());
            turf.setRating(notification.getRating());
            turf.setAddress(notification.getAddress());
            turf.setServices(notification.getServices());
            turf.setPhone(notification.getPhone());
            turf.setImage(notification.getImage());
            turfRepository.save(turf);
            notificationRepository.deleteById(id);
        });
    }

    public void declineNotification(Long id) {
        notificationRepository.deleteById(id);
    }
}
