package com.example.demo.controller;

import com.example.demo.model.Notification;
import com.example.demo.service.NotificationService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    @Autowired
    private NotificationService notificationService;

    @GetMapping
    public ResponseEntity<List<Notification>> getAllNotifications() {
        List<Notification> notifications = notificationService.getAllNotifications();
        return ResponseEntity.ok(notifications);
    }

    @PostMapping
    public ResponseEntity<Notification> addNotification(@RequestBody Notification notification) {
        try {
            Notification addedNotification = notificationService.addNotification(notification);
            return ResponseEntity.ok(addedNotification);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/{id}/accept")
    public ResponseEntity<Void> acceptNotification(@PathVariable Long id) {
        notificationService.acceptNotification(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/{id}/decline")
    public ResponseEntity<Void> declineNotification(@PathVariable Long id) {
        notificationService.declineNotification(id);
        return ResponseEntity.noContent().build();
    }
}
