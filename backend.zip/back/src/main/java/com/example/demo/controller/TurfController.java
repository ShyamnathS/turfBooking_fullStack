package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Turf;
import com.example.demo.service.TurfService;

@CrossOrigin(origins = "http://localhost:3000") // Replace with your React app's origin
@RestController
@RequestMapping("/api/turfs")
public class TurfController {

    @Autowired
    private TurfService turfService;

    @GetMapping
    public ResponseEntity<List<Turf>> getAllTurfs() {
        List<Turf> turfs = turfService.getAllTurfs();
        return ResponseEntity.ok(turfs);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Turf> getTurfById(@PathVariable Long id) {
        Turf turf = turfService.getTurfById(id);
        return turf != null ? ResponseEntity.ok(turf) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<Turf> addTurf(@RequestBody Turf turf) {
        try {
            Turf addedTurf = turfService.addTurf(turf);
            return ResponseEntity.ok(addedTurf);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Turf> updateTurf(@PathVariable Long id, @RequestBody Turf updatedTurf) {
        Turf turf = turfService.updateTurf(id, updatedTurf);
        return turf != null ? ResponseEntity.ok(turf) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTurf(@PathVariable Long id) {
        try {
            turfService.deleteTurf(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
