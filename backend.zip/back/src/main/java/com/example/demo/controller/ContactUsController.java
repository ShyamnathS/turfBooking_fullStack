package com.example.demo.controller;

import com.example.demo.model.ContactRequest;
import com.example.demo.repository.ContactRequestRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/contact")
@CrossOrigin(origins = "http://localhost:3000") // Replace with your frontend URL
public class ContactUsController {

    @Autowired
    private ContactRequestRepository contactRequestRepository;

    @PostMapping("/submit")
    public ContactRequest submitContactForm(@RequestBody ContactRequest contactRequest) {
        return contactRequestRepository.save(contactRequest);
    }
}
