import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';
import NavBar from './components/NavBar';
import TurfCard from './components/TurfCard';
import ContactUs from './components/ContactUs';
import Advertise from './components/Advertise';
import Footer from './components/Footer';
import SignIn from './components/SignIn';
import SignUp from './components/SignUp';
import BookingPage from './components/BookingPage';
import PaymentPage from './components/PaymentPage';
import Admin from './components/Admin'; // Import Admin component
import Noti from './components/AdminNotifications'; // Import Admin component
import './App.css';

function App() {
  const [location, setLocation] = useState('');
  const [turfType, setTurfType] = useState('');
  const [ratingFilter, setRatingFilter] = useState('');
  const [data, setData] = useState([]); // Set initial state to an empty array

  useEffect(() => {
    fetch('http://localhost:8080/api/turfs') // Replace with your Spring Boot API URL
      .then(response => response.json())
      .then(turfs => {
        const updatedTurfs = turfs.map(turf => ({
          ...turf,
          image: `data:image/jpeg;base64,${turf.image}`,
          services: Array.isArray(turf.services) ? turf.services : turf.services.split(',') // Ensure services is an array
        }));
        setData(updatedTurfs);
      })
      .catch(error => console.error('Error fetching turf data:', error));
  }, []);

  const filteredTurfs = data.filter((turf) => {
    const matchesLocation = location === '' || turf.address.toLowerCase().includes(location.toLowerCase());
    const matchesTurfType = turfType === '' || turf.services.some(service => service.toLowerCase().includes(turfType.toLowerCase()));

    let matchesRating = true;
    if (ratingFilter) {
      const ratingRanges = {
        'below 2': [0, 2],
        '2 - 3': [2, 3],
        '3 - 4': [3, 4],
        '4 - 5': [4, 5],
      };
      const [minRating, maxRating] = ratingRanges[ratingFilter] || [0, 5];
      matchesRating = turf.rating >= minRating && turf.rating < maxRating;
    }

    return matchesLocation && matchesTurfType && matchesRating;
  });

  return (
    <Router>
      <div className="App">
        <ConditionalNavBar setLocation={setLocation} setTurfType={setTurfType} setRatingFilter={setRatingFilter} />
        <Routes>
          <Route path="/" element={
            <div className="turf-list">
              {filteredTurfs.map((turf, index) => (
                <TurfCard
                  key={index}
                  id={turf.id}
                  image={turf.image}
                  title={turf.title}
                  rating={turf.rating}
                  address={turf.address}
                  services={turf.services}
                  phone={turf.phone}
                />
              ))}
            </div>
          } />
          <Route path="/contact-us" element={<ContactUs />} />
          <Route path="/advertise" element={<Advertise />} />
          <Route path="/signin" element={<SignIn />} />
          <Route path="/signup" element={<SignUp />} />
          <Route path="/booking/:id" element={<BookingPage turfData={data} />} />
          <Route path="/payment" element={<PaymentPage />} />
          <Route path="/admin" element={<Admin />} /> {/* Add Admin route */}
          <Route path="/noti" element={<Noti />} /> {/* Add Admin route */}
        </Routes>
        <Footer />
      </div>
    </Router>
  );
}

function ConditionalNavBar({ setLocation, setTurfType, setRatingFilter }) {
  const location = useLocation();
  return location.pathname !== '/admin' && (
    <NavBar setLocation={setLocation} setTurfType={setTurfType} setRatingFilter={setRatingFilter} />
  );
}

export default App;
