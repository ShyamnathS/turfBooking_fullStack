import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import './NavBar.css';
import logo from './images/logo1.jpeg';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faMapMarkerAlt, faUserCircle } from '@fortawesome/free-solid-svg-icons';

function NavBar({ setLocation, setTurfType, setRatingFilter }) {
  const location = useLocation();
  const [navList, setNavList] = useState(false);
  const [showProfileCard, setShowProfileCard] = useState(false);
  const [user, setUser] = useState(null);

  useEffect(() => {
    const storedUser = localStorage.getItem('user');
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  const handleSearch = () => {
    const locationValue = document.querySelector('.location-select').value;
    const turfTypeValue = document.querySelector('.turf-type-select').value;
    const ratingValue = document.querySelector('.rating-select').value;
    setLocation(locationValue);
    setTurfType(turfTypeValue);
    setRatingFilter(ratingValue);
  };

  const shouldShowDropdowns = !['/advertise', '/contact-us', '/signin', '/signup'].includes(location.pathname);

  const handleProfileClick = () => {
    setShowProfileCard(!showProfileCard);
  };

  const handleLogout = () => {
    localStorage.removeItem('user'); // Remove user info from local storage
    setUser(null);
    console.log('Logged out');
  };

  return (
    <header>
      <div className='container flex'>
        <div className='logo'>
          <img src={logo} alt='Logo' />
        </div>
        <div className={`nav ${navList ? 'small' : 'flex'}`}>
          <ul>
            {shouldShowDropdowns && (
              <li className="input-wrapper">
                <FontAwesomeIcon icon={faMapMarkerAlt} className="location-icon" />
                <select className="location-select">
                  <option value="">Select Location</option>
                  <option value="Sundarapuram, Coimbatore">Sundarapuram, Coimbatore</option>
                  <option value="Singanallur, Coimbatore">Singanallur, Coimbatore</option>
                  <option value="Ramanathapuram, Coimbatore">Ramanathapuram, Coimbatore</option>
                  <option value="Peelamedu, Coimbatore">Peelamedu, Coimbatore</option>
                  <option value="Saibaba Colony, Coimbatore">Saibaba Colony, Coimbatore</option>
                  <option value="RS Puram, Coimbatore">RS Puram, Coimbatore</option>
                  <option value="Gandhipuram, Coimbatore">Gandhipuram, Coimbatore</option>
                  <option value="Ukkadam, Coimbatore">Ukkadam, Coimbatore</option>
                  <option value="Saravanampatti, Coimbatore">Saravanampatti, Coimbatore</option>
                </select>
              </li>
            )}
            {shouldShowDropdowns && (
              <li className="input-wrapper">
                <select className="turf-type-select">
                  <option value="">Select Turf Type</option>
                  <option value="Cricket">Cricket</option>
                  <option value="Football">Football</option>
                  <option value="Basketball">Basketball</option>
                  <option value="Tennis">Tennis</option>
                  <option value="Badminton">Badminton</option>
                  <option value="Table Tennis">Table Tennis</option>
                  <option value="Squash">Squash</option>
                  <option value="Swimming">Swimming</option>
                  <option value="Yoga">Yoga</option>
                  <option value="Hockey">Hockey</option>
                  <option value="Volleyball">Volleyball</option>
                </select>
                <select className="rating-select">
                  <option value="">Select Rating</option>
                  <option value="below 2">Below 2</option>
                  <option value="2 - 3">2 - 3</option>
                  <option value="3 - 4">3 - 4</option>
                  <option value="4 - 5">4 - 5</option>
                </select>
                <button className="search-button" onClick={handleSearch}>Search</button>
              </li>
            )}
            <li>
              <Link to={location.pathname === '/advertise' ? '/' : '/advertise'} className="navbar-link">
                {location.pathname === '/advertise' ? 'Home' : 'Advertise'}
              </Link>
            </li>
            <li>
              <Link to={location.pathname === '/contact-us' ? '/' : '/contact-us'} className="navbar-link">
                {location.pathname === '/contact-us' ? "Let's Play" : 'Contact Us'}
              </Link>
            </li>
            <li>
              <Link to="/signin" className="navbar-link">Login / Sign Up</Link>
            </li>
            <li className="profile-icon" onClick={handleProfileClick}>
              <FontAwesomeIcon icon={faUserCircle} size="2x" />
              {showProfileCard && user && (
                <div className="profile-card">
                  <p>Name: {user.name}</p>
                  <p>Email: {user.email}</p>
                  <button onClick={handleLogout} className="logout-button">Log Out</button>
                </div>
              )}
            </li>
          </ul>
        </div>
        <div className='toggle'>
          <button onClick={() => setNavList(!navList)}>
            {navList ? <i className='fa fa-times'></i> : <i className='fa fa-bars'></i>}
          </button>
        </div>
      </div>
    </header>
  );
}

export default NavBar;
