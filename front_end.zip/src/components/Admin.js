import React, { useState, useEffect } from 'react';
import axios from 'axios';
import {
  Container,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  TextField,
  Grid,
  Typography,
  Box,
  IconButton,
  AppBar,
  Toolbar,
} from '@mui/material';
import NotificationsIcon from '@mui/icons-material/Notifications';
import { styled } from '@mui/material/styles';
import { useNavigate } from 'react-router-dom'; // Import useNavigate

const CustomContainer = styled(Container)({
  marginTop: '32px',
});

const CustomTableContainer = styled(TableContainer)({
  marginBottom: '32px',
});

const Form = styled('form')({
  '& .MuiTextField-root': {
    margin: '8px',
    width: '25ch',
  },
});

const SubmitButton = styled(Button)({
  margin: '16px 0',
});

const NotificationSection = styled(Box)({
  display: 'flex',
  alignItems: 'center',
  marginBottom: '16px', // Adjust margin as needed
});

function Admin() {
  const [turfs, setTurfs] = useState([]);
  const [newTurf, setNewTurf] = useState({
    title: '',
    address: '',
    rating: '',
    services: '',
    phone: '',
    image: '',
  });

  const navigate = useNavigate(); // Initialize useNavigate

  useEffect(() => {
    fetchTurfs();
  }, []);

  const fetchTurfs = async () => {
    try {
      const response = await axios.get('http://localhost:8080/api/turfs');
      const updatedTurfs = response.data.map((turf) => ({
        ...turf,
        services: Array.isArray(turf.services) ? turf.services : turf.services.split(','),
      }));
      setTurfs(updatedTurfs);
    } catch (error) {
      console.error('Error fetching turf data:', error);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewTurf({ ...newTurf, [name]: value });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      setNewTurf({ ...newTurf, image: reader.result.split(',')[1] });
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8080/api/turfs', newTurf);
      const updatedTurf = {
        ...response.data,
        services: Array.isArray(response.data.services) ? response.data.services : response.data.services.split(','),
      };
      setTurfs([...turfs, updatedTurf]);
      setNewTurf({ title: '', address: '', rating: '', services: '', phone: '', image: '' });
    } catch (error) {
      console.error('Error creating new turf:', error);
    }
  };

  const handleUpdate = async (id, updatedTurf) => {
    try {
      const response = await axios.put(`http://localhost:8080/api/turfs/${id}`, updatedTurf);
      const updatedTurfData = {
        ...response.data,
        services: Array.isArray(response.data.services) ? response.data.services : response.data.services.split(','),
      };
      setTurfs(turfs.map((turf) => (turf.id === id ? updatedTurfData : turf)));
    } catch (error) {
      console.error('Error updating turf:', error);
    }
  };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:8080/api/turfs/${id}`);
      setTurfs(turfs.filter((turf) => turf.id !== id));
    } catch (error) {
      console.error('Error deleting turf:', error);
    }
  };

  const handleNotificationClick = () => {
    navigate('/noti'); // Navigate to the AdminNotifications page
  };

  return (
    <CustomContainer>
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" style={{ flexGrow: 1 }}>
            Admin Page
          </Typography>
        </Toolbar>
      </AppBar>

      <Typography variant="h4" component="h1" gutterBottom>
        Turf Management
      </Typography>

      {/* Notification section */}
      <NotificationSection>
        <IconButton color="primary" onClick={handleNotificationClick}>
          <NotificationsIcon />
        </IconButton>
        <Typography variant="body1" style={{ marginLeft: '8px' }}>
          You have new notifications
        </Typography>
      </NotificationSection>

      <CustomTableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Title</TableCell>
              <TableCell>Address</TableCell>
              <TableCell>Rating</TableCell>
              <TableCell>Services</TableCell>
              <TableCell>Phone</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {turfs.map((turf) => (
              <TableRow key={turf.id}>
                <TableCell>{turf.title}</TableCell>
                <TableCell>{turf.address}</TableCell>
                <TableCell>{turf.rating}</TableCell>
                <TableCell>{turf.services.join(', ')}</TableCell>
                <TableCell>{turf.phone}</TableCell>
                <TableCell>
                  <Button
                    variant="contained"
                    color="primary"
                    onClick={() => handleUpdate(turf.id, { ...turf, title: 'Updated Title' })}
                  >
                    Update
                  </Button>
                  <Button
                    variant="contained"
                    color="secondary"
                    onClick={() => handleDelete(turf.id)}
                    style={{ marginLeft: '8px' }}
                  >
                    Delete
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CustomTableContainer>

      <Typography variant="h5" component="h2" gutterBottom>
        Add New Turf
      </Typography>
      <Form onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <TextField
              name="title"
              label="Title"
              value={newTurf.title}
              onChange={handleInputChange}
              required
              fullWidth
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              name="address"
              label="Address"
              value={newTurf.address}
              onChange={handleInputChange}
              required
              fullWidth
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              name="rating"
              label="Rating"
              value={newTurf.rating}
              onChange={handleInputChange}
              required
              fullWidth
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              name="services"
              label="Services (comma separated)"
              value={newTurf.services}
              onChange={handleInputChange}
              required
              fullWidth
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <TextField
              name="phone"
              label="Phone"
              value={newTurf.phone}
              onChange={handleInputChange}
              required
              fullWidth
            />
          </Grid>
          <Grid item xs={12} sm={6}>
            <Button variant="contained" component="label">
              Upload Image
              <input type="file" hidden onChange={handleFileChange} />
            </Button>
          </Grid>
          <Grid item xs={12}>
            <SubmitButton type="submit" variant="contained" color="primary">
              Add Turf
            </SubmitButton>
          </Grid>
        </Grid>
      </Form>
    </CustomContainer>
  );
}

export default Admin;
