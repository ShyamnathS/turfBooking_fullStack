import React, { useState } from 'react';
import './ContactUs.css';
import img from './images/card12.PNG'; // Ensure the path to your image is correct

function ContactUs() {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = (event) => {
    event.preventDefault();
  
    const contactData = {
      name: name,
      email: email,
      subject: subject,
      message: message,
    };
  
    fetch('http://localhost:8080/api/contact/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(contactData),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log('Success:', data);
        alert('Your message has been submitted!');
      })
      .catch((error) => {
        console.error('Error:', error);
        alert('There was an error submitting your message.');
      });
  };
  
  return (
    <>
      <section className='contact mb'>
        <div className='cover' style={{ backgroundImage: `url(${img})` }}>
          <div className='cover-text'>
            <h2>Contact Us</h2>
            <h4>Get Help & Friendly Support</h4>
          </div>
        </div>
        <div className='container'>
          <form className='shadow' onSubmit={handleSubmit}>
            <h4>Fill Up The Form</h4>
            <div>
              <input
                type='text'
                placeholder='Name'
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
              <input
                type='text'
                placeholder='Email'
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            <input
              type='text'
              placeholder='Subject'
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              required
            />
            <textarea
              cols='30'
              rows='10'
              placeholder='Message'
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              required
            />
            <button type='submit'>Submit Request</button>
          </form>
        </div>
      </section>
    </>
  );
}

export default ContactUs;
