import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {
  Container,
  Typography,
  Box,
  Button,
  Card,
  CardContent,
  CardActions,
  Grid,
  AppBar,
  Toolbar,
} from '@mui/material';
import { styled, ThemeProvider, createTheme } from '@mui/material/styles';

const lightTheme = createTheme({
  palette: {
    mode: 'light',
    background: {
      default: '#f5f5f5',
    },
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          backgroundColor: '#ffffff',
          color: '#000000',
        },
      },
    },
  },
});

const darkTheme = createTheme({
  palette: {
    mode: 'dark',
    background: {
      default: '#303030',
    },
  },
  components: {
    MuiCard: {
      styleOverrides: {
        root: {
          backgroundColor: '#424242',
          color: '#ffffff',
        },
      },
    },
  },
});

const CustomContainer = styled(Container)({
  marginTop: '32px',
  display: 'flex',
  flexDirection: 'column',
  alignItems: 'center',
  justifyContent: 'center',
  minHeight: '100vh',
});

const NotificationCard = styled(Card)({
  marginBottom: '16px',
  borderRadius: '8px',
  boxShadow: '0 2px 8px rgba(0, 0, 0, 0.1)',
  width: '100%', // Optional: Set a max width if you want to limit the card width
  maxWidth: '600px',
});

const NotificationTitle = styled(Typography)({
  fontWeight: 'bold',
  marginBottom: '8px',
});

const NotificationDetails = styled(Typography)({
  marginBottom: '8px',
});

const ActionButton = styled(Button)({
  margin: '0 8px',
});

function AdminNotifications() {
  const [notifications, setNotifications] = useState([]);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    async function fetchNotifications() {
      try {
        const response = await axios.get('http://localhost:8080/api/notifications');
        setNotifications(response.data);
      } catch (error) {
        console.error('Error fetching notifications:', error);
      }
    }
    fetchNotifications();
  }, []);

  const handleAccept = async (id) => {
    try {
      await axios.put(`http://localhost:8080/api/notifications/${id}/accept`);
      setNotifications(notifications.filter(n => n.id !== id));
    } catch (error) {
      console.error('Error accepting notification:', error);
    }
  };

  const handleDecline = async (id) => {
    try {
      await axios.put(`http://localhost:8080/api/notifications/${id}/decline`);
      setNotifications(notifications.filter(n => n.id !== id));
    } catch (error) {
      console.error('Error declining notification:', error);
    }
  };

  return (
    <ThemeProvider theme={isDarkMode ? darkTheme : lightTheme}>
      <Box>
        <AppBar position="static">
          <Toolbar>
            <Typography variant="h6" style={{ flexGrow: 1 }}>
              Admin Notifications
            </Typography>
            <Button color="inherit" onClick={() => setIsDarkMode(!isDarkMode)}>
              {isDarkMode ? 'Light Mode' : 'Dark Mode'}
            </Button>
          </Toolbar>
        </AppBar>

        <CustomContainer>
          <Typography variant="h4" component="h1" gutterBottom>
            Notification Management
          </Typography>

          {notifications.length === 0 ? (
            <Typography variant="body1">No new notifications.</Typography>
          ) : (
            <Grid container spacing={3} justifyContent="center">
              {notifications.map(notification => (
                <Grid item xs={12} key={notification.id}>
                  <NotificationCard>
                    <CardContent>
                      <NotificationTitle variant="h5">{notification.title}</NotificationTitle>
                      <NotificationDetails variant="body1">Address: {notification.address}</NotificationDetails>
                      <NotificationDetails variant="body1">Rating: {notification.rating}</NotificationDetails>
                      <NotificationDetails variant="body1">Services: {notification.services}</NotificationDetails>
                      <NotificationDetails variant="body1">Phone: {notification.phone}</NotificationDetails>
                    </CardContent>
                    <CardActions>
                      <ActionButton
                        variant="contained"
                        color="primary"
                        onClick={() => handleAccept(notification.id)}
                      >
                        Accept
                      </ActionButton>
                      <ActionButton
                        variant="outlined"
                        color="secondary"
                        onClick={() => handleDecline(notification.id)}
                      >
                        Decline
                      </ActionButton>
                    </CardActions>
                  </NotificationCard>
                </Grid>
              ))}
            </Grid>
          )}
        </CustomContainer>
      </Box>
    </ThemeProvider>
  );
}

export default AdminNotifications;
