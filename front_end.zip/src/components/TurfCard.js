import React, { useState } from 'react';
import './TurfCard.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faHeart, faCheckCircle, faLocationPin } from '@fortawesome/free-solid-svg-icons';
import { Dialog, DialogActions, DialogContent, DialogTitle, Button, Typography } from '@mui/material';

function TurfCard({ image, title, rating, address, services, phone, id }) {
  const [isFavorite, setIsFavorite] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);

  const getStarRating = (rating) => {
    const fullStars = Math.floor(rating);
    const hasHalfStar = rating % 1 !== 0;
    const halfStarWidth = hasHalfStar ? `${(rating % 1) * 100}%` : '0%';
    const emptyStars = 5 - fullStars - (hasHalfStar ? 1 : 0);

    return (
      <>
        {[...Array(fullStars)].map((_, index) => (
          <span key={`full-${index}`} className="star filled">★</span>
        ))}
        {hasHalfStar && (
          <span className="star half-filled" style={{ '--half-star-width': halfStarWidth }}>
            ★
          </span>
        )}
        {[...Array(emptyStars)].map((_, index) => (
          <span key={`empty-${index}`} className="star empty">★</span>
        ))}
      </>
    );
  };

  const toggleFavorite = () => {
    setIsFavorite(prevState => !prevState);
  };

  const handleDialogOpen = () => {
    setDialogOpen(true);
  };

  const handleDialogClose = () => {
    setDialogOpen(false);
  };

  return (
    <div className="turf-card">
      <img src={image} alt={title} className="turf-image" />
      <div className="turf-info">
        <div className="turf-header">
          <h2 className="turf-title">{title}</h2>
          <div className="verified-info">
            <FontAwesomeIcon icon={faCheckCircle} className="verified-icon" title="Verified" />
            <span className="verified-text">Verified</span>
          </div>
        </div>
        <div className="turf-rating">
          <div className="rating-info">
            <span className="rating-value">{rating}</span>
            <span className="rating-stars">{getStarRating(rating)}</span>
            <span className="rating-count">3 Ratings</span>
          </div>
        </div>
        <div className="turf-address">
          <FontAwesomeIcon icon={faLocationPin} className="address-icon" />
          <span>{address}</span>
        </div>
        <div className="turf-services">
          {services.map((service, index) => (
            <span key={index} className="service-tag">{service}</span>
          ))}
        </div>
        <div className="turf-actions">
          <button className="call-button" onClick={handleDialogOpen}>
            Call
          </button>
          <button className="book-slot-button">
            <a href={`/booking/${id}`} className="book-slot-link">Book Slot</a>
          </button>
          <button className={`favorite-button`} onClick={toggleFavorite}>
            <FontAwesomeIcon
              icon={faHeart}
              className={`heart-icon ${isFavorite ? 'favorited' : ''}`}
              title="Favorite"
            />
          </button>
        </div>
      </div>

      {/* Dialog for displaying phone number */}
      <Dialog open={dialogOpen} onClose={handleDialogClose}>
        <DialogTitle>Contact Phone Number</DialogTitle>
        <DialogContent>
          <Typography variant="body1">{phone}</Typography>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleDialogClose} color="primary">
            Close
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}

export default TurfCard;
