// src/components/TurfData.js
import image1 from './images/card1.PNG';
import image2 from './images/card2.PNG';
import image3 from './images/card3.PNG';
import image4 from './images/card4.PNG';
import image5 from './images/card5.PNG';
import image6 from './images/card6.PNG';
import image7 from './images/card7.PNG';
import image8 from './images/card8.PNG';
import image9 from './images/card9.PNG';
import image10 from './images/card10.PNG';
import image11 from './images/card11.PNG';
import image12 from './images/card12.PNG';
import image13 from './images/card13.PNG';
import image14 from './images/card14.PNG';
import image15 from './images/card15.PNG';
import image16 from './images/card16.PNG';
import image17 from './images/card17.PNG';

const turfData = [
  // ... turf data
  // (same as previously provided)
  {
    id: 1,
    image: image14,
    title: 'Legends Sports Complex',
    rating: 2.8,
    address: 'Kovaipudur, Coimbatore',
    services: ['Football', 'Cricket'],
    phone: '0654321092'
  },
  {
    id: 2,
    image: image2,
    title: 'Elite Sports Ground',
    rating: 4.5,
    address: 'Singanallur, Coimbatore',
    services: ['Tennis', 'Basketball'],
    phone: '0123456789'
  },
  {
    id: 3,
    image: image3,
    title: 'Star Sports Turf',
    rating: 4.8,
    address: 'Ramanathapuram, Coimbatore',
    services: ['Cricket', 'Football', 'Basketball'],
    phone: '0987654321'
  },
  {
    id: 4,
    image: image4,
    title: 'Green Field Arena',
    rating: 4.2,
    address: 'Peelamedu, Coimbatore',
    services: ['Badminton', 'Tennis', 'Volleyball'],
    phone: '0876543210'
  },
  {
    id: 5,
    image: image5,
    title: 'Ace Sports Hub',
    rating: 4.7,
    address: 'Saibaba Colony, Coimbatore',
    services: ['Table Tennis', 'Squash'],
    phone: '0765432109'
  },
  {
    id: 6,
    image: image6,
    title: 'Sports Kingdom',
    rating: 4.4,
    address: 'RS Puram, Coimbatore',
    services: ['Swimming', 'Yoga'],
    phone: '0654321098'
  },
  {
    id: 7,
    image: image7,
    title: 'Elite Turf',
    rating: 4.9,
    address: 'Gandhipuram, Coimbatore',
    services: ['Football', 'Tennis'],
    phone: '0543210987'
  },
  {
    id: 8,
    image: image8,
    title: 'Pro Sports Turf',
    rating: 4.6,
    address: 'Ukkadam, Coimbatore',
    services: ['Cricket', 'Hockey'],
    phone: '0432109876'
  },
  {
    id: 9,
    image: image9,
    title: 'Victory Sports Complex',
    rating: 4.3,
    address: 'Saravanampatti, Coimbatore',
    services: ['Basketball', 'Badminton'],
    phone: '0321098765'
  },
  {
    id: 10,
    image: image10,
    title: 'Premier Turf Ground',
    rating: 4.8,
    address: 'Singanallur, Coimbatore',
    services: ['Football', 'Cricket'],
    phone: '0210987654'
  },
  {
    id: 11,
    image: image11,
    title: 'Blue Sky Arena',
    rating: 3.7,
    address: 'Podanur, Coimbatore',
    services: ['Basketball', 'Football'],
    phone: '0987654322'
  },
  {
    id: 12,
    image: image12,
    title: 'Sunrise Sports Zone',
    rating: 3.0,
    address: 'Kuniamuthur, Coimbatore',
    services: ['Volleyball', 'Badminton'],
    phone: '0876543211'
  },
  {
    id: 13,
    image: image13,
    title: 'Champions Turf',
    rating: 4.1,
    address: 'Thudiyalur, Coimbatore',
    services: ['Tennis', 'Basketball'],
    phone: '0765432101'
  },
  {
    id: 14,
    image: image1,
    title: 'MSD Multi Sport Division',
    rating: 5,
    address: 'Sundarapuram, Coimbatore',
    services: ['Cricket', 'Football'],
    phone: '08460476832'
  },
  {
    id: 15,
    image: image15,
    title: 'Victory Arena',
    rating: 4.0,
    address: 'Sowripalayam, Coimbatore',
    services: ['Tennis', 'Swimming'],
    phone: '0543210983'
  },
  {
    id: 16,
    image: image16,
    title: 'Pro Active Sports Ground',
    rating: 3.5,
    address: 'Vadavalli, Coimbatore',
    services: ['Cricket', 'Yoga'],
    phone: '0432109874'
  },
  {
    id: 17,
    image: image17,
    title: 'Green Valley Turf',
    rating: 4.6,
    address: 'Vilankurichi, Coimbatore',
    services: ['Badminton', 'Football'],
    phone: '0321098766'
  },
  {
    id: 18,
    image: 'path/to/image18.jpg',
    title: 'Grand Sports Club',
    rating: 4.9,
    address: 'Ganapathy, Coimbatore',
    services: ['Basketball', 'Squash'],
    phone: '0210987655'
  },
  {
    id: 19,
    image: 'path/to/image19.jpg',
    title: 'Athletes Edge',
    rating: 4.4,
    address: 'KNG Pudur, Coimbatore',
    services: ['Volleyball', 'Tennis'],
    phone: '0109876543'
  },
  {
    id: 20,
    image: 'path/to/image20.jpg',
    title: 'Victory Park',
    rating: 3.9,
    address: 'Saibaba Colony, Coimbatore',
    services: ['Table Tennis', 'Football'],
    phone: '0998765432'
  }
];

export default turfData;
