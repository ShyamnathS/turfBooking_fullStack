// src/components/Notification.js
import React from 'react';
import './Notification.css';

const Notification = React.forwardRef(({ notifications }, ref) => (
  <div className="notification-dropdown" ref={ref}>
    {notifications.length === 0 ? (
      <p>No notifications</p>
    ) : (
      notifications.map((notification, index) => (
        <p key={index}>{notification}</p>
      ))
    )}
  </div>
));

export default Notification;
