// src/components/PaymentPage.js
import React, { useState } from 'react';
import { Box, Button, TextField, Typography, Grid, Card, CardContent } from '@mui/material';
import styled from '@emotion/styled';

const Root = styled(Box)`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  background-color: #f5f5f5;
  padding: 16px;
`;

const StyledCard = styled(Card)`
  max-width: 500px;
  width: 100%;
  padding: 24px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  background-color: #fff;
`;

const Title = styled(Typography)`
  margin-bottom: 24px;
  font-weight: bold;
`;

const StyledButton = styled(Button)`
  margin-top: 16px;
  padding: 12px;
  background-color: #1976d2;
  color: #fff;

  &:hover {
    background-color: #115293;
  }
`;

const StyledInput = styled(TextField)`
  margin-bottom: 16px;
`;

const PaymentPage = () => {
  const [cardName, setCardName] = useState('');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your payment processing logic here
    console.log('Payment Details:', { cardName, cardNumber, expiryDate, cvv });
  };

  return (
    <Root>
      <StyledCard>
        <CardContent>
          <Title variant="h5">Payment Details</Title>
          <form onSubmit={handleSubmit}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <StyledInput
                  label="Cardholder Name"
                  variant="outlined"
                  fullWidth
                  required
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <StyledInput
                  label="Card Number"
                  variant="outlined"
                  fullWidth
                  required
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                />
              </Grid>
              <Grid item xs={6}>
                <StyledInput
                  label="Expiry Date (MM/YY)"
                  variant="outlined"
                  fullWidth
                  required
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                />
              </Grid>
              <Grid item xs={6}>
                <StyledInput
                  label="CVV"
                  variant="outlined"
                  fullWidth
                  required
                  value={cvv}
                  onChange={(e) => setCvv(e.target.value)}
                />
              </Grid>
              <Grid item xs={12}>
                <StyledButton type="submit" variant="contained" fullWidth>
                  Pay Now
                </StyledButton>
              </Grid>
            </Grid>
          </form>
        </CardContent>
      </StyledCard>
    </Root>
  );
};

export default PaymentPage;
