import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom'; // Import useNavigate
import Calendar from 'react-calendar';
import 'react-calendar/dist/Calendar.css';
import { Box, Card, CardContent, CardMedia, Grid, Typography, ImageList, ImageListItem } from '@mui/material';
import Modal from 'react-modal';
import './BookingPage.css'; // Ensure you have this file for your styles
import './CalendarDarkTheme.css'; // Import the custom CSS for the dark theme
import i1 from './images/card10.PNG';
import i2 from './images/card1.PNG';
import i3 from './images/card11.PNG';
import i4 from './images/card12.PNG';
import i5 from './images/card13.PNG';
import i6 from './images/card14.PNG';
import i7 from './images/card16.PNG';
import i8 from './images/card17.PNG';
import i9 from './images/card2.PNG';
import i10 from './images/card3.PNG';
import i11 from './images/card4.PNG';

const dummyImages = [
  { img: i1, title: 'Image 1' },
  { img: i2, title: 'Image 2' },
  { img: i3, title: 'Image 3' },
  { img: i4, title: 'Image 4' },
  { img: i5, title: 'Image 5' },
  { img: i6, title: 'Image 6' },
  { img: i7, title: 'Image 7' },
  { img: i8, title: 'Image 8' },
  { img: i9, title: 'Image 9' },
  { img: i10, title: 'Image 10' },
  { img: i11, title: 'Image 11' }
];

const dummyReviews = [
  { name: 'John Doe', review: 'Great place to play! The facilities are top-notch and the staff is friendly. Highly recommended.', rating: 5, gender: 'male' },
  { name: 'Jane Smith', review: 'Had a fantastic time! The turf was well-maintained and the booking process was smooth.', rating: 4, gender: 'female' },
  { name: 'Sam Wilson', review: 'Highly recommend it! The environment is great, and the booking system is user-friendly.', rating: 5, gender: 'male' },
  { name: 'Emily Davis', review: 'Awesome experience! The turf was clean and well-organized.', rating: 4, gender: 'female' },
  { name: 'Michael Brown', review: 'Good value for money. The booking process was a bit slow, but overall a positive experience.', rating: 3, gender: 'male' },
  { name: 'Sophia Wilson', review: 'Loved the atmosphere. The facilities were excellent, and the staff was helpful.', rating: 5, gender: 'female' },
  { name: 'Chris Johnson', review: 'Decent place, but I encountered some issues with the booking system.', rating: 2, gender: 'male' }
];

const BookingPage = ({ turfData }) => {
  const { id } = useParams();
  const navigate = useNavigate(); // Initialize useNavigate
  const turf = turfData.find(turf => turf.id === parseInt(id));
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedTime, setSelectedTime] = useState('');
  const [modalIsOpen, setModalIsOpen] = useState(false);
  const [currentImage, setCurrentImage] = useState('');
  const [selectedSlots, setSelectedSlots] = useState([]);

  if (!turf) {
    return <div>Turf not found</div>;
  }

  const handleDateChange = date => {
    setSelectedDate(date);
  };

  const handleTimeChange = event => {
    setSelectedTime(event.target.value);
  };

  const handleSlotChange = (slot) => {
    setSelectedSlots(prevSlots =>
      prevSlots.includes(slot) ? prevSlots.filter(s => s !== slot) : [...prevSlots, slot]
    );
  };

  const openModal = (img) => {
    setCurrentImage(img);
    setModalIsOpen(true);
  };

  const closeModal = () => {
    setModalIsOpen(false);
    setCurrentImage('');
  };

  const availableTimes = [
    '08:00 AM', '10:00 AM', '12:00 PM', '02:00 PM', '04:00 PM', '06:00 PM'
  ];
  const bookedSlots = ['08:00 AM', '12:00 PM']; // Example booked slots

  const isSlotAvailable = (slot) => !bookedSlots.includes(slot);
  const isSlotSelected = (slot) => selectedSlots.includes(slot);

  // Define the minimum date as today
  const minDate = new Date();

  const handlePayNow = () => {
    // Navigate to the payment page
    navigate('/payment');
  };

  return (
    <div className="booking-page">
      <Card sx={{ width: '100%', marginBottom: 2 }}>
        <Grid container>
          <Grid item xs={12} sm={4}>
            <CardMedia
              component="img"
              height="100%"
              image={turf.image}
              alt={`${turf.title} main`}
            />
          </Grid>
          <Grid item xs={12} sm={8}>
            <CardContent>
              <Typography gutterBottom variant="h5" component="div">
                {turf.title}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Rating: {turf.rating}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Address: {turf.address}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Services: {turf.services.join(', ')}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Phone: {turf.phone}
              </Typography>
            </CardContent>
          </Grid>
        </Grid>
      </Card>

      <hr />

      <h3>Gallery</h3>
      <div className="gallery">
        <Box sx={{ width: '100%', overflowY: 'scroll' }}>
          <ImageList variant="masonry" cols={3} gap={8}>
            {dummyImages.map((item) => (
              <ImageListItem key={item.img} onClick={() => openModal(item.img)}>
                <img
                  src={`${item.img}?w=248&fit=crop&auto=format`}
                  srcSet={`${item.img}?w=248&fit=crop&auto=format&dpr=2 2x`}
                  alt={item.title}
                  loading="lazy"
                />
              </ImageListItem>
            ))}
          </ImageList>
        </Box>
      </div>

      <hr />

      <div className="booking-details">
        <div className="calendar-container">
          <div className="calendar-label">Select a Date:</div>
          <div className="calendar">
            <Calendar
              onChange={handleDateChange}
              value={selectedDate}
              minDate={minDate} // Set minimum date to today
              // Optionally add a theme or other calendar props here
            />
          </div>
        </div>

        <div className="time-slot-select">
          <Typography variant="h6">Select Time Slot:</Typography>
          <table className="time-slot-table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Availability</th>
              </tr>
            </thead>
            <tbody>
              {availableTimes.map((time) => (
                <tr
                  key={time}
                  className={isSlotAvailable(time) ? (isSlotSelected(time) ? 'selected' : 'available') : 'booked'}
                  onClick={() => isSlotAvailable(time) && handleSlotChange(time)}
                >
                  <td>{time}</td>
                  <td>{isSlotAvailable(time) ? (isSlotSelected(time) ? 'Selected' : 'Available') : 'Booked'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <button className="pay-now-button" onClick={handlePayNow}>Pay Now</button>
      </div>

      <hr />

      <div className="reviews">
        <Typography variant="h6">Reviews:</Typography>
        {dummyReviews.map((review, index) => (
          <div key={index} className="review">
            <div className="customer-face">
              {review.gender === 'male' ? '👨' : '👩'}
            </div>
            <div className="review-text">
              <p><strong>{review.name}</strong></p>
              <p>{review.review}</p>
              <p>{'★'.repeat(review.rating)}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Modal for viewing full-size images */}
      <Modal isOpen={modalIsOpen} onRequestClose={closeModal} className="modal">
        <img src={currentImage} alt="Full-size" />
        <button onClick={closeModal}>Close</button>
      </Modal>
    </div>
  );
};

export default BookingPage;
