import React, { useState } from 'react';
import Avatar from '@mui/material/Avatar';
import Button from '@mui/material/Button';
import CssBaseline from '@mui/material/CssBaseline';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Container from '@mui/material/Container';
import { createTheme, ThemeProvider } from '@mui/material/styles';
import { SportsSoccer as SportsSoccerIcon } from '@mui/icons-material';
import Grid from '@mui/material/Grid';
import { styled } from '@mui/material/styles';
import axios from 'axios';

const Label = styled('label')({
  display: 'flex',
  alignItems: 'center',
  marginRight: '16px',
  fontWeight: 'bold',
  minWidth: '150px',
});

const FormField = styled(Grid)({
  display: 'flex',
  alignItems: 'center',
  marginBottom: '16px',
});

const StyledTextField = styled(TextField)({
  flex: 1,
  minWidth: '300px',
});

const defaultTheme = createTheme();

export default function Advertise() {
  const [newTurf, setNewTurf] = useState({
    title: '',
    address: '',
    rating: '',
    services: '',
    phone: '',
    image: '',
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewTurf({ ...newTurf, [name]: value });
  };

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onloadend = () => {
      setNewTurf({ ...newTurf, image: reader.result.split(',')[1] });
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      await axios.post('http://localhost:8080/api/notifications', newTurf);
      alert('Advertise request submitted successfully.');
      setNewTurf({ title: '', address: '', rating: '', services: '', phone: '', image: '' });
    } catch (error) {
      console.error('Error submitting advertise request:', error);
    }
  };
  

  return (
    <ThemeProvider theme={defaultTheme}>
      <Container component="main" maxWidth="xs">
        <CssBaseline />
        <Box
          sx={{
            marginTop: 8,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
          }}
        >
          <Avatar sx={{ m: 1, bgcolor: 'secondary.main' }}>
            <SportsSoccerIcon />
          </Avatar>
          <Typography component="h1" variant="h5">
            Advertise Your Turf
          </Typography>
          <Box component="form" onSubmit={handleSubmit} noValidate sx={{ mt: 1 }}>
            <Grid container spacing={2}>
              <FormField item xs={12}>
                <Label htmlFor="title">Title:</Label>
                <StyledTextField
                  name="title"
                  id="title"
                  value={newTurf.title}
                  onChange={handleInputChange}
                  required
                />
              </FormField>
              <FormField item xs={12}>
                <Label htmlFor="address">Address:</Label>
                <StyledTextField
                  name="address"
                  id="address"
                  value={newTurf.address}
                  onChange={handleInputChange}
                  required
                />
              </FormField>
              <FormField item xs={12}>
                <Label htmlFor="rating">Rating:</Label>
                <StyledTextField
                  name="rating"
                  id="rating"
                  value={newTurf.rating}
                  onChange={handleInputChange}
                  required
                />
              </FormField>
              <FormField item xs={12}>
                <Label htmlFor="services">Services:</Label>
                <StyledTextField
                  name="services"
                  id="services"
                  value={newTurf.services}
                  onChange={handleInputChange}
                  required
                />
              </FormField>
              <FormField item xs={12}>
                <Label htmlFor="phone">Phone:</Label>
                <StyledTextField
                  name="phone"
                  id="phone"
                  value={newTurf.phone}
                  onChange={handleInputChange}
                  required
                />
              </FormField>
              <FormField item xs={12}>
                <Button variant="contained" component="label">
                  Upload Image
                  <input type="file" hidden onChange={handleFileChange} />
                </Button>
              </FormField>
              <Grid item xs={12}>
                <Button
                  type="submit"
                  fullWidth
                  variant="contained"
                  color="primary"
                  sx={{ mt: 3, mb: 2 }}
                >
                  Request to Advertise
                </Button>
              </Grid>
            </Grid>
          </Box>
        </Box>
      </Container>
    </ThemeProvider>
  );
}
